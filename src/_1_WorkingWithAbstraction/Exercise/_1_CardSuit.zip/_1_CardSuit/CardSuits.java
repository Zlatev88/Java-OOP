package _1_WorkingWithAbstraction.Exercise._1_CardSuit;

public enum CardSuits {
    CLUBS, DIAMONDS, HEARTS, SPADES
}
